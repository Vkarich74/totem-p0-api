BEGIN;

ALTER TABLE payments
ALTER COLUMN updated_at SET DEFAULT now();

COMMIT;
