# TOTEM — Error Codes Reference (v1)

This document reflects **actual production behavior**.
If behavior changes, this file MUST be updated.

==================================================
ERROR RESPONSE FORMAT
==================================================

```json
{
  "ok": false,
  "error": "ERROR_CODE",
  "message": "Human readable message"
}
