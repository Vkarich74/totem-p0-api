# TOTEM — PUBLIC BOOKING API v1 (CANONICAL)

**Status:** STABLE / FROZEN  
**Backend tag:** BACKEND_FREEZE_V1  
**Audience:** Frontend (Web / Mobile / Odoo), Partners  
**Write access:** Limited  
**Read access:** Public  

---

## BASE URL

