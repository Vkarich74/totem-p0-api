import "./db/index.js";
console.log("== SERVICES MIGRATION DONE ==");
