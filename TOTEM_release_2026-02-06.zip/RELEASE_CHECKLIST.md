# 🔒 TOTEM — RELEASE CHECKLIST v1 (CORE)

Status: READY  
Scope: CORE ONLY  
Environment: PROD (Railway)  
DB: PostgreSQL  

---

## ✅ HEALTH CHECK

```cmd
curl https://totem-p0-api-production.up.railway.app/health
